var msg_type;
var fuzz_count = 0;

function html_encode(rawStr){
    try{
        var encodedStr = rawStr.replace(/[\u00A0-\u9999<>\&]/gim, function(i) {
            return '&#'+i.charCodeAt(0)+';';
        });
        return encodedStr;
    }catch(e){
        return rawStr;
    }
}

function getURLPar(name, search) {
    return decodeURIComponent((new RegExp('[?|&]' + name + '=' + '([^&;]+?)(&|#|;|$)').exec(search)||[,""])[1].replace(/\+/g, '%20'))||null;
}

function onpage_load(){
    target = getURLPar("target",window.location.hash);
    msg = getURLPar("msg",window.location.hash);
    msg_type = getURLPar("type",window.location.hash);

    if(target){
        t = document.getElementById("url");
        t.value = decodeURIComponent(atob(target));
    }

    if(msg){
        m = document.getElementById("message");
        m.value = decodeURIComponent(window.atob(msg));
    }
}

window.onerror = function(e) {
    alert(e);
}

window.onmessage = function(e){
    $('#in').text($('#in').text() + JSON.stringify(e.data) + "\n--------------------------------\n");
};

jQuery(function($){
    var tests = {
        'PostMessage': function() {return 'postMessage' in $('#frame').get(0).contentWindow},
        'JSON': function() {return 'JSON' in window}
    };

    fails = [];
    for(var i in tests) {
        if(!tests[i]()) {
            fails.push(i);
        }
    };

    if(fails.length) {
        $('.fails').text(fails.join(', '));
        $('.error').show();
    }

    $('form').submit(function(e) { e.preventDefault(); });

    $('#btn-iframe').click(function(e){
        e.preventDefault();

        var frame = $('#frame');
        var url = $('#url').val();

        frame.attr('src', url);
        window.poc = frame.get(0).contentWindow;
        $('.writable-html').text('<iframe src="' + url + '" id="frame"></iframe>');
        $('.writable-js').text("var frame = document.getElementById('frame');\nwindow.poc = frame.contentWindow;\nframe.onload = function() {");
        $('.writable-js-2').text('};');
        $('#data-url').text('data:text/html;base64,' + window.btoa($('#poc').text()));
    });

    $('#btn-popup').click(function(e){
        e.preventDefault();

        $('#frame').attr('src', 'data:text/html,<html><body><strong>Inactive:</strong> exploit is using popup</body></html>');
        var url = $('#url').val();
        var popup = window.open(url);
        window.poc = popup;
        $('.writable-html').text('<input type="button" value="Open Popup" id="btn" />\n<input type="button" value="Fire Exploit" id="fire" />');
        $('.writable-js').text("document.getElementById('btn').onclick = function(e) {\nwindow.poc = window.open('" + url + "');\n};\ndocument.getElementById('fire').onclick = function(e) {");
        $('.writable-js-2').text('};');
    });

    $('#btn-string').click(function(e){
        e.preventDefault();
        var message = $('#message');
        window.poc.postMessage(message.val(), '*');

        var payload = "\nwindow.poc.postMessage('" + message.val().replace(/\\/g, '\\\\').replace(/'/g, "\\'").replace(/</g, "<' + '") + "', '*');";
        $('.writable-js').text($('.writable-js').text() + payload);
        $('#data-url').text('data:text/html;base64,' + window.btoa($('#poc').text()));
    });

    $('#btn-json').click(function(e){
        e.preventDefault();
        var message = $('#message');
        window.poc.postMessage(JSON.parse(message.val()), '*');

        var payload = "\nwindow.poc.postMessage(" + message.val() + ", '*');";
        $('.writable-js').text($('.writable-js').text() + payload);
        $('#data-url').text('data:text/html;base64,' + window.btoa($('#poc').text()));
    });

    function log_fuzz(data){
        try{
            data = JSON.stringify(data);
        }catch(e){}
        document.getElementById("fuzzer_log").innerHTML += html_encode(data) + "\n";
    }

    function fuzz_msgs(list, delay){
        var message_to_fuzz = list.pop();
        log_fuzz("--------------------------------");
        log_fuzz(message_to_fuzz);
        window.poc.postMessage(message_to_fuzz, '*');
        if(list.length > 0) {
            setTimeout(function(){
                fuzz_msgs(list, delay);
            }, delay);
        } else {
            log_fuzz("Done");
        }
    }

    $('#btn-simple-fuzz').click(function(e){
        e.preventDefault();

        var target_msg;
        if(msg_type && msg_type == "object"){
            target_msg = JSON.parse($('#message').val());
        } else {
            target_msg = $('#message').val();
        }

        var fuzzed_messages = simple_fuzz(target_msg, default_fuzz_callback);
        fuzz_msgs(fuzzed_messages, 1);
    });

    $('.tabs .tab').click(function(e){
        e.preventDefault();
        $('.tab.active').removeClass('active');
        $(this).addClass('active');
        $('.panel.active').removeClass('active');
        var select = $(this).find('a').attr('href');
        $(select).addClass('active');
    });
});

onpage_load();
