// popup.js

// HTML encoding to prevent injection
function html_encode(rawStr) {
    try {
        return rawStr.replace(/[\u00A0-\u9999<>\&]/gim, function(i) {
            return '&#' + i.charCodeAt(0) + ';';
        });
    } catch (e) {
        return rawStr;
    }
}

function toggleMe(id) {
    const el = document.getElementById(id);
    if (el) {
        el.style.display = el.style.display === "none" ? "block" : "none";
    }
}

function clear_output() {
    document.getElementById("output").innerHTML = "";
}

function cleardb() {
    localStorage.clear();
    clear_output();
}

function is_in_array(item, array) {
    return array.includes(item);
}

function we_have_the_handler(handler, handler_array) {
    return handler_array.some(obj => obj.handler === handler);
}

function we_have_the_message(message, message_array) {
    const data = message.data;
    return message_array.some(msg => {
        let m1 = data;
        let m2 = msg.data;

        if (typeof m1 === "object") {
            m1 = JSON.stringify(m1, (_, v) => v === undefined ? null : v);
            m2 = JSON.stringify(m2, (_, v) => v === undefined ? null : v);
        }

        return m1 === m2;
    });
}

function store_item(item) {
    const targetpage = item.to || item.href;
    const pageLog = JSON.parse(localStorage.getItem(targetpage) || '{"handlers":[],"messages":[]}');

    if (item.from && item.to && !we_have_the_message(item, pageLog.messages)) {
        pageLog.messages.push(item);
    }

    if (item.handler && !we_have_the_handler(item.handler, pageLog.handlers)) {
        pageLog.handlers.push(item);
    }

    localStorage.setItem(targetpage, JSON.stringify(pageLog, (_, v) => v === undefined ? null : v));
}

function create_header(type, text) {
    const header = document.createElement(type);
    const maxLength = 100;

    if (text.length > maxLength) {
        text = text.slice(0, maxLength) + " ....";
    }

    header.textContent = text;
    return header;
}

function get_host_for_url(url) {
    const a = document.createElement("a");
    a.href = url;
    return a.host;
}

function get_scheme_for_url(url) {
    const a = document.createElement("a");
    a.href = url;
    return a.protocol;
}

function dump_events() {
    clear_output();
    const outputDiv = document.getElementById("output");
    const filter = document.getElementById("url_filter").value;

    for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (filter) {
            try {
                const pattern = new RegExp(filter);
                if (!pattern.test(key)) continue;
            } catch (e) {
                console.error(e);
                continue;
            }
        }

        const item = JSON.parse(localStorage.getItem(key));
        const h = create_header("h2", key);
        h.onclick = () => toggleMe("results_div" + i);
        outputDiv.appendChild(h);

        const results_div = document.createElement("div");
        results_div.id = "results_div" + i;
        results_div.style.display = "none";

        const h3Handlers = create_header("h3", "Handlers");
        results_div.appendChild(h3Handlers);

        item.handlers.forEach((handlerObj, idx) => {
            results_div.appendChild(create_header("h4", "Handler: " + idx));
            const c = document.createElement("textarea");
            c.cols = "100";
            c.rows = 10;
            c.value = handlerObj.handler;
            results_div.appendChild(c);

            const a = document.createElement("a");
            const qs = btoa(key) + "&search_for=" + btoa(unescape(encodeURIComponent(handlerObj.handler)));
            a.href = `http://${location.host}:8080/search_for?url=${qs.replace("+", "%2b")}`;
            a.target = "_blank";
            a.textContent = "Search Handler";
            results_div.appendChild(a);
        });

        const h3Messages = create_header("h3", "Messages");
        results_div.appendChild(h3Messages);

        const tbl = document.createElement("table");
        const header = tbl.createTHead();
        const headers = ["Data", "Message From", "Replay"];
        headers.forEach((text, i) => {
            const th = document.createElement("th");
            th.innerHTML = `<b>${text}</b>`;
            th.width = i === 2 ? "10%" : "45%";
            header.appendChild(th);
        });

        item.messages.forEach((msg, ct) => {
            const row = tbl.insertRow(ct);
            const data = msg.data;
            const from = msg.from;
            const type = typeof data;

            const msg_body = type === "object"
                ? JSON.stringify(data, (_, v) => v === undefined ? null : v)
                : data;

            const cell1 = row.insertCell(0);
            const cell2 = row.insertCell(1);
            const cell3 = row.insertCell(2);

            cell1.innerHTML = html_encode(msg_body);
            cell2.innerHTML = html_encode(from);

            const replayBtn = document.createElement("a");
            replayBtn.textContent = "Replay";
            replayBtn.title = "click";
            replayBtn.href = "#";
            replayBtn.onclick = (e) => {
                e.preventDefault();
                const target_url = btoa(encodeURIComponent(key));
                const qs = `target=${target_url}&msg=${btoa(encodeURIComponent(msg_body))}&type=${type}`;
                const replay_url = `${location.origin}/replay.html#?${qs.replace("+", "%2b")}`;

                const win = window.open("", "", "width=800,height=580,toolbar=no,menubar=no,resizable=yes");
                win.document.write(`
                    <html>
                    <head><style>body, html {width: 100%; height: 100%; margin: 0; padding: 0}</style></head>
                    <body><iframe src="${replay_url}" style="height:100%;width:100%"></iframe></body>
                    </html>
                `);
            };
            cell3.appendChild(replayBtn);
        });

        results_div.appendChild(tbl);
        outputDiv.appendChild(results_div);
    }
}

function recv_message(event) {
    try {
        if (event.data?.post_message_hook) {
            store_item(event.data);
        }
    } catch (e) {
        console.error(e);
    }

    try {
        if (event.data === "dumpevents") {
            console.log(localStorage.eventdb);
        }
    } catch (e) {
        console.error(e);
    }
}

document.addEventListener("DOMContentLoaded", () => {
    document.getElementById("dumpevents").addEventListener("click", dump_events);
    document.getElementById("url_filter").addEventListener("keyup", function(event) {
        if (event.key === "Enter") {
            dump_events();
        }
    });
    document.getElementById("clearoutput").addEventListener("click", clear_output);
    document.getElementById("cleardb").addEventListener("click", cleardb);
    window.addEventListener("message", recv_message);
    parent.postMessage("logger_iframe_ready", "*");
});
