function openLoggerPopup() {
  const extensionId = "mjohdillgacmiggnljlgkhmmnmbpchfp";
  const url = `chrome-extension://${extensionId}/logger.html`;
  const features = [
    'width=800',
    'height=600',
    'left=100',
    'top=100',
    'resizable=yes',
    'scrollbars=yes',
    'toolbar=no',
    'location=no',
    'status=no',
    'menubar=no',
    'directories=no'
  ].join(',');
  window.open(url, 'LoggerPopup', features);
}

document.getElementById('about-btn').addEventListener('click', () => {
  const width = 500, height = 400;
  const left = (screen.width / 2) - (width / 2);
  const top = (screen.height / 2) - (height / 2);
  const aboutWin = window.open(
    '',
    'kiran',
    `width=${width},height=${height},left=${left},top=${top},toolbar=no,location=no,status=no,menubar=no,resizable=yes,scrollbars=yes`
  );
  aboutWin.document.write(`
    <html><head><title>About</title><style>
      body { font-family: Arial,sans-serif; padding: 20px; background: #f9f9f9; margin:0; }
      h2 { color: #355681; margin-top: 0; }
      p { font-size: 1.1em; line-height: 1.4; }
      button { margin-top: 20px; padding: 8px 16px; font-size: 1em; background: #3498db; border: none; border-radius: 5px; color: white; cursor: pointer; }
      button:hover { background: #3cb0fd; }
    </style></head><body>
    <h2>About</h2>
    <p>This is the PostMessage Tool extension.<br> Created by KiranReddyRebel <br>Thanks to Appcheck-ng poc code<br><br>https://github.com/kiranreddyrebel</p>
    </body></html>
  `);
});

document.getElementById('open-logger-btn').addEventListener('click', openLoggerPopup);
