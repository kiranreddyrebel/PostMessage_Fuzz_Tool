click = function() {
    chrome.tabs.create({
        url: 'open.html#',
        active: false
    });
}

about = function() {
    chrome.tabs.create({
        url: 'about.html#',
        active: false
    });
}

onload = function() {
    document.querySelector('#click').onclick = click;
	document.querySelector('#about').onclick = about;
}

window.onload = onload;