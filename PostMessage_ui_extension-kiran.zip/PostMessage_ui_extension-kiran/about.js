window.close();

var iframe = '<html><head><style>body, html {width: 100%; height: 100%; margin: 0; padding: 0}</style></head><body><h1>PostMessage Tool by Kiranreddyrebel</h1><br><p>Thanks to Appcheck-NG for the Code & POC which i modded for ChromeApp for offline use instead of online .</p><a href="https://github.com/kiranreddyrebel">Github</a><br><br><p>How to use ? Please check in my github for this.</html></body>';

var win = window.open("","","width=500,height=300,toolbar=no,menubar=no,resizable=yes");
win.document.write(iframe);

